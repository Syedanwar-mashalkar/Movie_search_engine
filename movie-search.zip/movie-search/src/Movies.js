import { faSearch } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import axios from "axios";
import React, { useState } from "react";
import { Link } from "react-router-dom";
import './Movies.css'; // Import the CSS file

const API_KEY = '1e94ff26';  // Replace with your OMDB API key

function Movies() {
  const [searchTerm, setSearchTerm] = useState("");
  const [searchMovies, setSearchMovies] = useState([]);
  const [errorMessage, setErrorMessage] = useState("");
  const [loading, setLoading] = useState(false);

  async function fetchMovies(event) {
    setLoading(true);
    event.preventDefault();
    try {
      const response = await axios.get(
        `https://www.omdbapi.com/?i=tt3896198&apikey=${API_KEY}&s=${searchTerm}`
      );
      setLoading(false);
      if (response.data.Response === "True" && response.data.Search) {
        setSearchMovies(response.data.Search);
        setErrorMessage("");
      } else {
        setSearchMovies([]);
        setErrorMessage("No movies found :( TRY AGAIN");
      }
    } catch (error) {
      console.error("Error fetching movies: ", error);
      setSearchMovies([]);
      setErrorMessage("Failed to fetch movies, please try again later");
    }
  }

  function sortMovies(filter) {
    const sortedMovies = [...searchMovies];
    if (filter === "Latest-Movies") {
      sortedMovies.sort((a, b) =>
        parseInt(b.Year) - parseInt(a.Year)
      );
    } else if (filter === "Oldest-Movies") {
      sortedMovies.sort((a, b) =>
        parseInt(a.Year) - parseInt(b.Year)
      );
    }
    setSearchMovies(sortedMovies);
  }

  return (
    <section id="movie__page" className="bg-gradient flex flex-col w-full min-h-screen">
      <div className="search-container">
        <h1>Movie Explorer</h1>
        <form onSubmit={fetchMovies} className="search-form">
          <input
            type="text"
            className="search-input"
            placeholder="Search movie..."
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <button
            type="submit"
            className="search-button"
          >
            <FontAwesomeIcon icon={faSearch} />
          </button>
        </form>
        
        {errorMessage && <h2 className="text-red-500">{errorMessage}</h2>}
        {loading ? (
          <div className="loader-container">
            <div className="bouncing-dots">
              <div className="dot"></div>
              <div className="dot"></div>
              <div className="dot"></div>
            </div>
          </div>
        ) : (
          <div className="movie-container">
            {searchMovies.map((movie) => (
              <div key={movie.imdbID} className="movie-card">
                <Link to={`/movies/${movie.imdbID}`}>
                  <img src={movie.Poster} alt={movie.Title} />
                  <div className="movie-card-content">
                    <h3>{movie.Title}</h3>
                    <p>{movie.Year}</p>
                  </div>
                </Link>
              </div>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}

export default Movies;
